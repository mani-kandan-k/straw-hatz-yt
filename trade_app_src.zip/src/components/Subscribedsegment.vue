<template>
  <div>
    <v-container fluid fill-height>
      <v-row align="center" justify="center">
        <v-col cols="12" sm="8" md="6">
          <v-form ref="form" v-model="valid" lazy-validation>
            <v-card max-width="200">

              <v-col cols="auto" class="text-center">
                <v-checkbox input-value="true" value disabled label="NSE"></v-checkbox>
                <v-checkbox   value disabled label="BSE"></v-checkbox>
                <v-checkbox  value disabled label="MCX"></v-checkbox>
              </v-col>
            </v-card>
          </v-form>
        </v-col>
      </v-row>

      <!-- <div class="text-center">
            <v-btn :disabled="!valid" @click="submit">Submit</v-btn>
          </div> -->


    </v-container>
  </div>
</template>

<script>
export default {
  data() {
    return {
      valid: false
    };
  },
  // methods: {
  //   submit() {
  //     if (this.$refs.form.validate()) {
  //       alert('Subscribed segments: ' + this.subscribedSegments.join(', '));
  //     }
  //   },
  // },
};
</script>

<style></style>