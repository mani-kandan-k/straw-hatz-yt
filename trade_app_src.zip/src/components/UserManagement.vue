<template>
  <v-container fluid fill-height>
    <h1 style="margin-left: 650px;">USER MANAGEMENT</h1>
    <br>
    <v-row justify="center">
      <v-col cols="12" sm="8" md="3">
        <v-form @submit.prevent="saveUser">
          <v-card>
            <v-card-title class="text-center">{{ isEdit ? 'Update User' : 'Create User' }}</v-card-title>
            <v-card-text>
              <v-row>
                <v-col cols="12">
                  <v-text-field v-model="userId" prepend-icon="mdi-account-circle" label="User ID" clearable required></v-text-field>
                </v-col>
                <v-col cols="12">
                  <v-text-field v-model="username" prepend-icon="mdi-account" label="Username" clearable required></v-text-field>
                </v-col>
                <v-col cols="12">
                  <v-select v-model="role" :items="roles" prepend-icon="mdi-account-group" label="Role" clearable required></v-select>
                </v-col>
                <v-col cols="12">
                  <v-select v-model="status" :items="statuses" prepend-icon="mdi-list-status" label="Status" required></v-select>
                </v-col>
              </v-row>
            </v-card-text>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="primary" type="submit">{{ isEdit ? 'Update User' : 'Create User' }}</v-btn>
            </v-card-actions>
          </v-card>
        </v-form>
      </v-col>
    </v-row>

    <v-row justify="center" class="mt-5">
      <v-col cols="12" sm="12" md="8">
        <usertable :users="users" @edit="editUser" @delete="deleteUser"></usertable>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import usertable from "../components/usertable.vue";

export default {
  data() {
    return {
      userId: '',
      username: '',
      role: null,
      status: null,
      roles: ['Client', 'Admin', 'Billing approver'],
      statuses: ['Active', 'Inactive'],
      users: [],
      isEdit: false,
      editIndex: -1
    };
  },
  components: {
    usertable
  },
  methods: {
    saveUser() {
      if (this.userId && this.username && this.role && this.status) {
        const user = {
          userId: this.userId,
          username: this.username,
          role: this.role,
          roleStatus: this.status
        };

        if (this.isEdit) {
       
          this.$set(this.users, this.editIndex, user);
        } else {

          this.users.push(user);
        }
        
        this.resetForm();
      }
    },
    editUser(user, index) {
      this.userId = user.userId;
      this.username = user.username;
      this.role = user.role;
      this.status = user.roleStatus;
      this.isEdit = true;
      this.editIndex = index;
    },
    deleteUser(user) {
      const index = this.users.indexOf(user);
      if (index !== -1) {
        this.users.splice(index, 1);
      }
    },
    resetForm() {
      this.userId = '';
      this.username = '';
      this.role = null;
      this.status = null;
      this.isEdit = false;
      this.editIndex = -1;
    }
  }
};
</script>

<style scoped>
/* .header-cell {
  background-color: #BDBDBD;
  color: white;
} */
</style>
