<template>
    <div>

        <v-tabs v-model="activeTab">
            <v-tab>Transaction</v-tab>
            <v-tab>User Management </v-tab>
            <v-tab>Configuration </v-tab>
            <v-tab>Bank Master </v-tab>
            <v-tab>Billing</v-tab>
        </v-tabs>
            <Transaction v-if="activeTab == 0"></Transaction>
            <UserManagement v-else-if="activeTab==1"></UserManagement> 
         <Configuration v-else-if="activeTab==2"></Configuration> 
         <Bankmaster v-else-if="activeTab==3"></Bankmaster>  
         <Billing v-else-if="activeTab==4"></Billing>  
    </div>
</template>
<script>
import Transaction from "../components/Transaction.vue";
import UserManagement from "./UserManagement.vue";
import Configuration from "./Configuration.vue";
import Bankmaster from "./Bankmaster.vue";
import Billing from "./Billing.vue";



export default {
    data() {
        return {
            activeTab: 0
        }

    },
    components: {
        Transaction,
        UserManagement,
        Configuration,
        Bankmaster,
        Billing
    }
}
</script>