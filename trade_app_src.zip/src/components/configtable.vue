<template>
    <v-container>
      <v-data-table :headers="headers" :items="charges" class="elevation-1">
        <template v-slot:top>
          <v-toolbar flat>
            <v-toolbar-title>Config Management</v-toolbar-title>
          </v-toolbar>
        </template>
        <template v-slot:item.actions="{ item }">
          <v-icon small class="mr-2" @click="$emit('edit', item)">
            mdi-pencil
          </v-icon>
          <v-icon small @click="$emit('delete', item)">
            mdi-delete
          </v-icon>
        </template>
        <template v-slot:no-data>
          <v-btn color="primary" @click="$emit('initialize')">Reset</v-btn>
        </template>
      </v-data-table>
    </v-container>
  </template>
  
  <script>
  export default {
    props: {
      charges: {
        type: Array,
        default: () => []
      }
    },
    data() {
      return {
        headers: [
          { text: 'Charge Type', value: 'chargeType',class: 'header-cell' },
          { text: 'Charge Percentage', value: 'chargePercentage',class: 'header-cell' },
          { text: 'Effective Date', value: 'effectiveDate',class: 'header-cell' },
          { text: 'Actions', value: 'actions', sortable: false ,class: 'header-cell'}
        ]
      };
    }
  };
  </script>
  
  <style scoped>

  </style>
  