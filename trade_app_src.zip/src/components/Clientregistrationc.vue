<template>
  <div>
    <h1 class="text-center mb-4">Client Registration</h1>
    <div class="text-right" style="margin-right: 70px;">
      <v-btn @click="resetForm"  depressed color="#EEEEEE">
                Refresh  <v-icon>mdi-refresh</v-icon>
            </v-btn>
    </div>
    <v-container>
      <v-form ref="form" v-model="valid" lazy-validation @submit.prevent="submitform">
        <v-card>
          <v-row justify="center">
            <v-col cols="12" sm="6" md="4">
              <v-text-field v-model="user.firstName" :rules="nameRules" label="First Name" prepend-icon="mdi-account"
                clearable ></v-text-field>
            </v-col>
            <v-col cols="12" sm="6" md="4">
              <v-text-field v-model="user.lastName" :rules="nameRules" label="Last Name" prepend-icon="mdi-account"
                clearable required></v-text-field>
            </v-col>
            <v-col cols="12" sm="6" md="4">
              <v-text-field v-model="user.email" :rules="emailRules" label="Email" prepend-icon="mdi-email" clearable
                required></v-text-field>
            </v-col>
            <v-col cols="12" sm="6" md="4">
              <v-text-field v-model="user.phoneNumber" :rules="phoneRules" label="Phone Number" prepend-icon="mdi-phone"
                clearable required></v-text-field>
            </v-col>
            <v-col cols="12" sm="6" md="4">
              <v-text-field v-model="user.panCardNumber" :rules="panRules" label="PAN Card Number"
                prepend-icon="mdi-credit-card" clearable required></v-text-field>
            </v-col>
            <v-col cols="12" sm="6" md="4">
              <v-text-field v-model="user.nomineeName" :rules="nameRules" label="Nominee Name"
                prepend-icon="mdi-account-circle" clearable required></v-text-field>
            </v-col>
            <v-col cols="12" sm="6" md="4">
              <v-select v-model="user.bankName" :items="bank" label="Bank Name" prepend-icon="mdi-bank" clearable
                required></v-select>
            </v-col>
            <v-col cols="12" sm="6" md="4">
              <v-select v-model="user.branchName" :items="branch" label="Branch Name" prepend-icon="mdi-bank-plus" clearable
                required></v-select>
            </v-col>
            <v-col cols="12" sm="6" md="4">
              <v-text-field v-model="user.ifscCode" :rules="ifscRules" label="IFSC Code" prepend-icon="mdi-key"
                clearable required></v-text-field>
            </v-col>
            <v-col cols="12" sm="6" md="4">
              <v-text-field v-model="user.bankAccountNumber" :rules="accountNumberRules" label="Bank Account Number"
                prepend-icon="mdi-account-circle" clearable required></v-text-field>
            </v-col>
            <v-col cols="12" sm="6" md="4">
              <v-textarea v-model="user.address" :rules="addressRules" rows="1" label="Address" prepend-icon="mdi-home"
                clearable required></v-textarea>
            </v-col>
            <v-col cols="12" sm="6" md="4">
              <v-select v-model="user.kycStatus" :items="kycOptions" label="KYC Status" prepend-icon="mdi-check-circle"
                required></v-select>
            </v-col>
          </v-row>
        </v-card>
        <br>
        <br>
        <div class="text-center">
          <v-btn color="success" type="submit" large>Register</v-btn>
        </div>
      </v-form>
    </v-container>
  </div>
</template>

<script>
//import { mapMutations } from 'vuex';

export default {
  data() {
    return {
      valid: false,
      user: {
        firstName: '',
        lastName: '',
        email: '',
        phoneNumber: '',
        panCardNumber: '',
        nomineeName: '',
        bankName: '',
        branchName: '',
        ifscCode: '',
        bankAccountNumber: '',
        address: '',
        kycStatus: null,
      },
      kycOptions: ['Completed', 'Pending'],
      bank: ['CUB', 'SBI', 'IOB'],
      branch: ['CHENNAI', 'MADURAI', 'TRICHY'],
      nameRules: [
        (v) => !!v || 'This field is required',
        (v) => /^[a-zA-Z\s]+$/.test(v) || 'Name must contain only letters and spaces',
        (v) => (v && v.length <= 50) || 'Name must be less than 50 characters',
      ],
      emailRules: [
        (v) => !!v || 'Email is required',
        (v) => /.+@.+\..+/.test(v) || 'Must be a valid email format',
      ],
      phoneRules: [
        (v) => !!v || 'Phone number is required',
        (v) => /^\d{10}$/.test(v) || 'Must be a valid 10-digit phone number',
      ],
      panRules: [
        (v) => !!v || 'PAN is required',
        (v) => /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(v) || 'Invalid PAN format',
      ],
      ifscRules: [
        (v) => !!v || 'IFSC code is required',
        (v) => /^[A-Z]{4}0[A-Z0-9]{6}$/.test(v) || 'Invalid IFSC format',
      ],
      accountNumberRules: [
        (v) => !!v || 'Account number is required',
        (v) => /^\d{9,18}$/.test(v) || 'Must be a valid account number (9 to 18 digits)',
      ],
      addressRules: [
        (v) => !!v || 'Address is required',
        (v) => (v && v.length <= 100) || 'Address must be less than 100 characters',
      ],
    };
  },
  methods: {
   // ...mapMutations(['setuser']),
    submitform() {
      if (this.$refs.form.validate()) {
        this.$store.commit("setuser", this.user);
        this.$router.push('/client');
      }
    },
    resetForm() {
      this.user = {
        firstName: '',
        lastName: '',
        email: '',
        phoneNumber: '',
        panCardNumber: '',
        nomineeName: '',
        bankName: '',
        branchName: '',
        ifscCode: '',
        bankAccountNumber: '',
        address: '',
        kycStatus: null,
      };
      this.$refs.form.reset();
    },
  },
};
</script>

<style scoped>
/* .text-center {
  text-align: center;
} */
</style>
