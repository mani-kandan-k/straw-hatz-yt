<template>
    <v-container>
        <h1 class="text-center">Trade Execution</h1>
        <v-row justify="center">
            <v-col cols="12" sm="8" md="6">
                <v-card>
                    <v-card-text>
                        <v-form ref="form" v-model="valid" lazy-validation>
                            <v-row>
                                <v-col cols="12" sm="6" md="4">
                                    <v-select 
                                        v-model="selectedStock" 
                                        :items="stockOptions" 
                                        label="Select Stock" 
                                        @change="updateStockDetails" 
                                        required
                                    ></v-select>
                                </v-col>
                                <v-col cols="12" sm="6" md="4">
                                    <v-text-field v-model="segment" prepend-icon="mdi-segment" label="Segment" readonly></v-text-field>
                                </v-col>
                                <v-col cols="12" sm="6" md="4">
                                    <v-text-field v-model="isin" prepend-icon="mdi-wallet-outline" label="ISIN" readonly></v-text-field>
                                </v-col>
                                <v-col cols="12" sm="6" md="4">
                                    <v-text-field v-model="currentPrice" prepend-icon="mdi-cash" label="Current Price" readonly></v-text-field>
                                </v-col>
                                <v-col cols="12" sm="6" md="4">
                                    <v-text-field 
                                        v-model="quantity" 
                                        label="Quantity" 
                                        type="number" 
                                        required 
                                        @input="calculateTotal"
                                        :rules="[v => v > 0 || 'Quantity must be positive']"
                                    ></v-text-field>
                                </v-col>
                                <v-col cols="12" sm="6" md="4">
                                    <v-select v-model="tradeType" :items="tradeTypes" label="Trade Type" required></v-select>
                                </v-col>
                                <v-col cols="12" sm="6" md="4">
                                    <v-text-field v-model="estimatedTotal" label="Estimated Total" readonly></v-text-field>
                                </v-col>
                                <v-col cols="12" sm="6" md="6">
                                    <v-text-field :value="$store.state.user.kycStatus" label="KYC STATUS" readonly></v-text-field>
                                </v-col>
                                <v-col cols="12" class="text-center">
                                    <v-btn :disabled="!valid" @click="submitTrade">Submit Trade</v-btn>
                                </v-col>
                            </v-row>
                        </v-form>
                    </v-card-text>
                </v-card>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
export default {
    data() {
        return {
            valid: false,
            selectedStock: null,
            stockOptions: ["Stock A", "Stock B", "Stock C"],
            segment: "Equity",
            isin: "US1234567890",
            currentPrice: 100,
            quantity: null,
            tradeType: null,
            tradeTypes: ["Buy", "Sell"],
            estimatedTotal: 0,
        };
    },
    methods: {
        // updateStockDetails() {
            
        // },
        calculateTotal() {
            this.estimatedTotal = this.quantity && this.currentPrice ? this.quantity * this.currentPrice : 0;
        },
        submitTrade() {
            if (this.$refs.form.validate()) {
                
                this.$emit('trade-submitted', { selectedStock: this.selectedStock, quantity: this.quantity, tradeType: this.tradeType });
                this.$router.push({ name: 'TradeConfirmation' }); 
            }
        },
    },
};
</script>

<style>

</style>
