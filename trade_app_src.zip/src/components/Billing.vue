<template>
    <div>
        <v-container>
            <v-form v-if="!showApproval" @submit.prevent="generateBill" ref="billingForm">
                <h1>Billing Generation</h1>
                <v-row>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.clientId" label="Client ID" prepend-icon="mdi-account" :rules="requiredRule"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.tradeId" label="Trade ID" prepend-icon="mdi-tag" :rules="requiredRule"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.transactionDate" type="date" prepend-icon="mdi-calendar" :rules="requiredRule"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.stockName" prepend-icon="mdi-chart-line" label="Stock Name" :rules="requiredRule"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.quantity" :rules="numericRules" prepend-icon="mdi-finance" label="Quantity"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.brokeragePercentage" :rules="numericRules" prepend-icon="mdi-percent" label="Brokerage Percentage"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.sttPercentage" :rules="numericRules" prepend-icon="mdi-percent-outline" label="STT Percentage"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.dematCharges" :rules="numericRules" prepend-icon="mdi-plus-box" label="Demat Charges"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.totalCharges" :rules="numericRules" prepend-icon="mdi-calculator" label="Total Charges"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-btn color="success" type="submit">Generate Bill</v-btn>
                    </v-col>
                </v-row>
            </v-form>
            <BillingApproval v-else :billing-data="billing" @go-back="showApproval = false" />
        </v-container>
    </div>
</template>

<script>
import BillingApproval from '../components/BillingApproval.vue';

export default {
    components: {
        BillingApproval,
    },
    data() {
        return {
            showApproval: false,
            billing: {
                clientId: this.$store.state.trans.clientId,
                tradeId: this.$store.state.trans.tradeId,
                transactionDate: this.$store.state.trans.transactionDate,
                stockName: this.$store.state.trans.stockName,
                quantity: this.$store.state.trans.quantity,
                brokeragePercentage: '',
                sttPercentage: '',
                dematCharges: '',
                totalCharges: ''
            },
            requiredRule: [
                (v) => !!v || 'Field is required'
            ],
            numericRules: [
                (v) => !!v || 'Field is required',
                (v) => !isNaN(v) || 'Must be a number'
            ],
        };
    },
    methods: {
        generateBill() {
            if (this.$refs.billingForm.validate()) {
                this.showApproval = true;
            }
        }
    }
};
</script>

<style scoped>
</style>
