<template>
    <div>
        
        <v-container>
           
            <v-form v-if="!showPdfBill" @submit.prevent="submitApproval">
                
                <h1>Billing Approval</h1><v-row>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.clientId" prepend-icon="mdi-billboard" label="Billing ID" required></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.clientId" prepend-icon="mdi-account" label="Client ID" required></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.tradeId" prepend-icon="mdi-tag" label="Trade ID" required></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.totalCharges" prepend-icon="mdi-calculator"  label="Total Amount" required></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.brokeragePercentage" prepend-icon="mdi-percent" label="Brokerage" required></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.sttPercentage" prepend-icon="mdi-percent-outline" label="STT" required></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.dematCharges" prepend-icon="mdi-plus-box"  label="Demat Charges" required></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-select v-model="billing.status" prepend-icon="mdi-list-status" :items="statuses" label="Status" required></v-select>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.comments"  prepend-icon="mdi-comment-multiple" label="Comments"></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-btn color="success" type="submit">Submit Approval</v-btn>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-btn @click="$emit('go-back')">Go Back</v-btn>
                    </v-col>
                </v-row>
            </v-form>
            <Pdfbill v-if="showPdfBill" :billingData="billing" @go-back="showPdfBill = false" />
        </v-container>
    </div>
</template>

<script>
import Pdfbill from '../components/Pdfbill.vue';

export default {
    props: {
        billingData: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            statuses: ['Active', 'Inactive'],
            billing: { ...this.billingData },
            showPdfBill: false, 
        };
    },
    components: {
        Pdfbill
    },
    methods: {
        submitApproval() {
            
            this.showPdfBill = true; 
        }
    }
};
</script>

<style scoped>

</style>
