<template>
    <div>
      <v-container>
        <h1 class="text-center">Config Charges Management</h1> <br>
        <v-form @submit.prevent="addOrUpdateCharge">
          <v-card>
            <v-row justify="center">
              <v-col cols="12" sm="6" md="3">
                <v-select v-model="selectedCharge" prepend-icon="mdi-format-list-bulleted-type" :items="charges" label="Charge Type" required></v-select>
              </v-col>
              <v-col cols="12" sm="6" md="4">
                <v-text-field v-model="chargePercentage" prepend-icon="mdi-percent"  label="Charge Percentage" type="number" required></v-text-field>
              </v-col>
              <v-col cols="12" sm="6" md="4">
                <v-text-field v-model="effectiveDate" prepend-icon="mdi-calendar" label="Effective Date" type="date" required></v-text-field>
              </v-col>
            </v-row>
            <v-row justify="center">
              <v-col cols="12" sm="6" md="3">
                <v-btn color="primary" type="submit">Add/Update Charge</v-btn>
              </v-col>
              
            </v-row>
            <configtable :charges="chargesList" @edit="editCharge" @delete="deleteCharge"></configtable>
          </v-card>
        </v-form>
      </v-container>
    </div>
  </template>
  
  <script>
  import configtable from "../components/configtable.vue";
  
  export default {
    data() {
      return {
        selectedCharge: null,
        chargePercentage: null,
        effectiveDate: null,
        charges: ['STT', 'Brokerage', 'Demat'],
        chargesList: []
      };
    },
    components: {
      configtable
    },
    methods: {
      addOrUpdateCharge() {
        if (this.selectedCharge && this.chargePercentage && this.effectiveDate) {
          const chargeData = {
            chargeType: this.selectedCharge,
            chargePercentage: this.chargePercentage,
            effectiveDate: this.effectiveDate
          };
  
        
          const existingIndex = this.chargesList.findIndex(charge => charge.chargeType === this.selectedCharge);
          if (existingIndex !== -1) {
          
            this.chargesList.splice(existingIndex, 1, chargeData);
          } else {
           
            this.chargesList.push(chargeData);
          }
  
          this.selectedCharge = null;
          this.chargePercentage = null;
          this.effectiveDate = null;
        }
      },
      editCharge(charge) {
        this.selectedCharge = charge.chargeType;
        this.chargePercentage = charge.chargePercentage;
        this.effectiveDate = charge.effectiveDate;
      },
      deleteCharge(charge) {
        const index = this.chargesList.indexOf(charge);
        if (index !== -1) {
          this.chargesList.splice(index, 1);
        }
      }
    }
  };
  </script>
  
  <style scoped>

  </style>
  