<template>
    <div>

    <v-tabs v-model="activeTab">
        <v-tab >Profile Overview</v-tab>
        <v-tab >Bank Details</v-tab>
        <v-tab> Subscribed segment</v-tab>
        <v-tab> Recent trades</v-tab>
        <v-tab> Trade Execution</v-tab>
    </v-tabs>
    <Profile v-if="activeTab == 0"></Profile>
    <Bankdetails v-else-if="activeTab == 1 "></Bankdetails>
    <Subscribedsegment v-else-if="activeTab == 2 "></Subscribedsegment>
    <Recenttrades v-else-if="activeTab == 3 "></Recenttrades>
    <Tradeexecution v-else-if="activeTab == 4"></Tradeexecution>
    </div>
</template>

<script>
import Profile from "../components/Profile.vue";
import Bankdetails from "../components/Bankdetails";
import Subscribedsegment from "../components/Subscribedsegment.vue";
import Recenttrades from "../components/Recenttrades.vue";
import Tradeexecution from "../components/Tradeexecution.vue"
export default {
    data(){
        return{
            activeTab:0
        }
    },

    methods: {
        // navigateToProfile() {
        //     this.$router.push('/profile');
        // },
        // Bankdetails() {
        //     this.$router.push('/bank');

        // }
    },
    components:{
        Profile,
        Bankdetails,
        Subscribedsegment,
        Recenttrades,
        Tradeexecution

    }
}
</script>

<style></style> 