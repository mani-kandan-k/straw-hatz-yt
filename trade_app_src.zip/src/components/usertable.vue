<template>
    <v-container>
      <v-data-table :headers="headers" :items="users" class="elevation-1">
        <template v-slot:item.actions="{ item }">
          <v-icon small class="mr-2" @click="$emit('edit', item)">
            mdi-pencil
          </v-icon>
          <v-icon small @click="$emit('delete', item)">
            mdi-delete
          </v-icon>
        </template>
        <template v-slot:no-data>
          <v-btn color="primary" @click="$emit('initialize')">Reset</v-btn>
        </template>
      </v-data-table>
    </v-container>
  </template>
  
  <script>
  export default {
    props: {
      users: {
        type: Array,
        default: () => []
      }
    },
    data() {
      return {
        headers: [
          { text: 'Username', value: 'username', class: 'header-cell' },
          { text: 'User ID', value: 'userId', class: 'header-cell' },
          { text: 'Role', value: 'role', class: 'header-cell' },
          { text: 'Role Status', value: 'roleStatus', class: 'header-cell' },
          { text: 'Actions', value: 'actions', sortable: false, class: 'header-cell' }
        ]
      };
    }
  };
  </script>
  
  <style >
  .header-cell {
    background-color: #BDBDBD;
    color: white;
  }
  </style>
  