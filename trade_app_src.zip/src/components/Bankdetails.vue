<template>
    <div>
        <h1 class="text-center mb-4">Bank Details</h1>
        <v-container fluid fill-height>
            <v-row align="center" justify="center">
                <v-col cols="12" sm="8" md="4">
                    <v-card>
                        <v-card-title class="text-center">Bank Information</v-card-title>
                        <v-card-text>
                            <v-form ref="form" lazy-validation>
                                <v-row>
                                    <v-col cols="12">
                                        <v-text-field
                                            :value="$store.state.user.bankName"
                                            label="Bank Name"
                                            prepend-icon="mdi-bank"
                                            class="rounded"
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="12">
                                        <v-text-field
                                            :value="$store.state.user.branchName"
                                            label="Branch Name"
                                            required
                                            prepend-icon="mdi-home" 
                                            class="rounded"
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="12">
                                        <v-text-field
                                            :value="$store.state.user.ifscCode"
                                            label="IFSC Code"
                                            required
                                            prepend-icon="mdi-key"
                                            class="rounded"
                                        ></v-text-field>
                                    </v-col>
                                    <v-col cols="12">
                                        <v-text-field
                                            :value="$store.state.user.bankAccountNumber"
                                            label="Bank Account Number"
                                            prepend-icon="mdi-account"
                                            class="rounded"
                                        ></v-text-field>
                                    </v-col>
                                </v-row>
                            </v-form>
                        </v-card-text>
                       
                        <!-- <v-card-actions>
                            <v-btn :disabled="!valid" @click="submit" color="primary">Submit</v-btn>
                        </v-card-actions> -->
                    </v-card>
                </v-col>
            </v-row>
        </v-container>
    </div>
</template>

<script>
export default {
    // data() {
    //     return {
    //         valid: false,
    //     };
    // },
    // methods: {
    //     submit() {
    //         if (this.$refs.form.validate()) {
    //             alert('Form submitted!');
    //         }
    //     },
    // },
};
</script>

<style>
.text-center {
    font-weight: bold;
}

.mb-4 {
    margin-bottom: 16px; 
}

.rounded {
    border-radius: 8px; 
}


</style>
