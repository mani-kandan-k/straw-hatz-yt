<template>
    <v-container>
        <h1 class="text-center mb-4">Backoffice Transaction Management</h1>
        <div class="text-right">
            <v-btn @click="resetForm" depressed color="#EEEEEE">
                Refresh <v-icon>mdi-refresh</v-icon>
            </v-btn>
        </div>
        <br>

        <v-card>
            <v-form v-if="!showApproval" ref="form" v-model="valid" lazy-validation @submit.prevent="update">
                <v-row justify="center">
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="trans.transactionDate" label="Transaction Date" type="date"
                            prepend-icon="mdi-calendar" :rules="[v => !!v || 'Transaction date is required']">
                        </v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="4">
                        <v-text-field v-model="trans.clientId" label="Client ID" prepend-icon="mdi-account"
                            :rules="[v => !!v || 'Client ID is required']">
                        </v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="trans.tradeId" label="Trade ID" prepend-icon="mdi-tag"
                            :rules="[v => !!v || 'Trade ID is required']">
                        </v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="trans.stockName" label="Stock Name" prepend-icon="mdi-chart-line"
                            :rules="[v => !!v || 'Stock Name is required']">
                        </v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="4">
                        <v-text-field v-model="trans.quantity" label="Quantity" type="number" prepend-icon="mdi-finance"
                            :rules="[v => (v > 0) || 'Quantity must be greater than zero']">
                        </v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-select v-model="trans.tradeType" :items="tradeTypes" label="Trade Type"
                            prepend-icon="mdi-cart" :rules="[v => !!v || 'Trade Type is required']">
                        </v-select>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-select v-model="trans.settlementStatus" :items="settlementStatuses" label="Settlement Status"
                            prepend-icon="mdi-check-circle" :rules="[v => !!v || 'Settlement Status is required']">
                        </v-select>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-btn :disabled="!valid" color="success" type="submit" large>Update Status</v-btn>
                    </v-col>
                </v-row>
            </v-form>
            <Billing v-else :trans-data="trans" @go-back="showApproval = false"></Billing>
        </v-card>
    </v-container>
</template>

<script>
import Billing from "../components/Billing.vue";

export default {
    components: {
        Billing
    },
    data() {
        return {
            valid: false,
            trans: {
                transactionDate: '',
                clientId: '',
                tradeId: '',
                stockName: '',
                quantity: null,
                tradeType: null,
                settlementStatus: null,
            },
            tradeTypes: ["Buy", "Sell"],
            settlementStatuses: ["Pending", "Completed"],
            showApproval: false,
        };
    },
    methods: {
        update() {
            if (this.$refs.form.validate()) {
                this.showApproval = true;
                this.$store.commit("settrans", this.trans);
            }
        },
        resetForm() {
            this.trans = {
                transactionDate: '',
                clientId: '',
                tradeId: '',
                stockName: '',
                quantity: null,
                tradeType: null,
                settlementStatus: null,
            };
            this.$refs.form.reset();
            this.valid = false;
        }
    },
};
</script>

<style scoped>
.text-center {
    text-align: center;
}

.mb-4 {
    margin-bottom: 16px;
}
</style>
