<template>
    <div class="logo">
        <v-row align="center" justify="center">
            <v-card max-width="1200" style="margin-top: 200px;">
                <v-img src="../assets/logo.png" max-height="400" max-width="400" alt="Logo"></v-img>
                <v-card>
                    <v-col class="text-center" cols="12">
                        <h4 class="subheading">Sign in to continue!</h4>
                        <br>
                        <div>
                            <v-btn @click="login" elevation="10" outlined>Login</v-btn>
                        </div>
                        <br>
                        <div>
                            <a href="http://localhost:8080/admin#/admin">Admin login</a>
                        </div>
                    </v-col>
                </v-card>
            </v-card>
        </v-row>
    </div>
</template>

<script>
export default {
    methods: {
        login() {
            this.$router.push('/signup'); 
        }
    }
}
</script>

<style>
.logo {
    height: 734px;
    background: rgb(34,193,195);
    background: linear-gradient(0deg, #7F7FD5 5%, #91EAE4 100%);
}
</style>
