<template>
    <v-card>
        <v-navigation-drawer v-model="drawer" :mini-variant.sync="mini" permanent>
            <v-list-item class="px-2">
                <v-list-item-avatar>
                    <v-img src="https://randomuser.me/api/portraits/men/85.jpg"></v-img>
                </v-list-item-avatar>

                <v-list-item-title>John Leider</v-list-item-title>

                <v-btn icon @click.stop="mini = !mini">
                    <v-icon>mdi-chevron-left</v-icon>
                </v-btn>
            </v-list-item>

            <v-divider></v-divider>

            <v-list v-model="activeTab" dense>
                <v-list-item v-for="item in items" :key="item.title" link>
                    <v-list-item-icon>
                        <v-icon>{{ item.icon }}</v-icon>
                    </v-list-item-icon>

                    <v-list-item-content>
                        <v-list-item-title>{{ item.title }}</v-list-item-title>
                    </v-list-item-content>
                </v-list-item>
            </v-list>
            <Profile v-if="activeTab == 0"></Profile>
            <Bankdetails v-else-if="activeTab == 1"></Bankdetails>
            <Subscribedsegment v-else-if="activeTab == 2"></Subscribedsegment>
            <Tradeexecution v-else-if="activeTab == 3"></Tradeexecution>
        </v-navigation-drawer>
    </v-card>
</template>
<script>
import Profile from "../components/Profile.vue";
import Bankdetails from "../components/Bankdetails";
import Subscribedsegment from "../components/Subscribedsegment.vue";
import Tradeexecution from "../components/Tradeexecution.vue"
export default {
    data() {
        return {
            drawer: true,
            items: [
                { title: 'Bank Details', icon: 'mdi-home-city' },
                { title: 'Segment', icon: 'mdi-account' },
                { title: 'Trade', icon: 'mdi-account-group-outline' },
            ],
            mini: true,
            activeTab: 0
        }
    },
    components: {
        Profile,
        Bankdetails,
        Subscribedsegment,
        Tradeexecution

    }
}
</script>