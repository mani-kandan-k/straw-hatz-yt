<template>
    <div>
        <v-container>
            <v-form>
                <h1>PDF Generation</h1>
                <v-row>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.clientId" prepend-icon="mdi-billboard" label="Billing ID" required></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field :value="$store.state.user.firstName" prepend-icon="mdi-account"  label="Client Name" required></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.tradeId" prepend-icon="mdi-tag" label="Trade ID" required></v-text-field>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-text-field v-model="billing.totalCharges" prepend-icon="mdi-calculator"  label="Total Charges" required></v-text-field>
                    </v-col>
                </v-row>
                <v-row>
                    <v-col cols="12" sm="6" md="3">
                        <v-btn color="primary">Generate PDF</v-btn>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-btn color="success" prepend-icon="mdi-file-pdf-box">Download PDF</v-btn>
                    </v-col>
                    <v-col cols="12" sm="6" md="3">
                        <v-btn @click="$emit('go-back')">Go Back</v-btn>
                    </v-col>
                </v-row>
            </v-form>
        </v-container>
    </div>
</template>

<script>
export default {
    props: {
        billingData: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            billing: { ...this.billingData }
        };
    },
};
</script>
