<template>
    <div>
      <v-container>
        <h1 class="text-center">Bank Master Management</h1> <br>
        <v-form @submit.prevent="addOrUpdateBank">
          <v-card>
            <v-row justify="center">
              <v-col cols="12" sm="6" md="3">
                <v-text-field v-model="bankName" prepend-icon="mdi-bank" label="Bank Name" required></v-text-field>
              </v-col>
              <v-col cols="12" sm="6" md="3">
                <v-text-field v-model="branchName" prepend-icon="mdi-bank-plus" label="Branch Name" required></v-text-field>
              </v-col>
              <v-col cols="12" sm="6" md="3">
                <v-text-field v-model="ifscCode" prepend-icon="mdi-key"  label="IFSC Code" required></v-text-field>
              </v-col>
              <v-col cols="12" sm="6" md="3">
                <v-textarea v-model="address" rows="1" prepend-icon="mdi-home" label="Address" clearable required></v-textarea>
              </v-col>
            </v-row>
            <v-row justify="center">
              <v-col cols="12" sm="6" md="3">
                <v-btn color="primary" type="submit">Add Bank</v-btn>
              </v-col>
              <!-- <v-col cols="12" sm="6" md="3">
                <v-btn color="warning" @click="updateBank">Update Bank</v-btn>
              </v-col>
              <v-col cols="12" sm="6" md="3">
                <v-btn color="red" @click="deleteBank">Delete Bank</v-btn>
              </v-col> -->
            </v-row>
            <Bankmastertable :banks="banks" @edit="editBank" @delete="deleteBank"></Bankmastertable>
          </v-card>
        </v-form>
      </v-container>
    </div>
  </template>
  
  <script>
  import Bankmastertable from "../components/Bankmastertable.vue";
  
  export default {
    components: {
      Bankmastertable,
    },
    data() {
      return {
        bankName: '',
        branchName: '',
        ifscCode: '',
        address: '',
        banks: [],
        editingBank: null,
      };
    },
    methods: {
      addOrUpdateBank() {
        const bankData = {
          bankName: this.bankName,
          branchName: this.branchName,
          ifscCode: this.ifscCode,
          address: this.address,
        };
  
        if (this.editingBank) {
         
          const index = this.banks.indexOf(this.editingBank);
          this.banks.splice(index, 1, bankData);
          this.editingBank = null;
        } else {
      
          this.banks.push(bankData);
        }
  
        
        this.clearForm();
      },
      editBank(bank) {
        this.editingBank = bank;
        this.bankName = bank.bankName;
        this.branchName = bank.branchName;
        this.ifscCode = bank.ifscCode;
        this.address = bank.address;
      },
      deleteBank(bank) {
        const index = this.banks.indexOf(bank);
        if (index !== -1) {
          this.banks.splice(index, 1);
        }
      },
      clearForm() {
        this.bankName = '';
        this.branchName = '';
        this.ifscCode = '';
        this.address = '';
        this.editingBank = null;
      },
    },
  };
  </script>
  
  <style scoped>

  </style>
  