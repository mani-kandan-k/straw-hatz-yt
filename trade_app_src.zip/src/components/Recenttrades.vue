<template>
  <v-app>
    <v-container>
      <v-data-table :headers="headers" :items="trades" class="elevation-1">
        <template v-slot:top>
          <v-toolbar flat>
            <v-toolbar-title>Recent Trades</v-toolbar-title>
          </v-toolbar>
        </template>

        <template v-slot:item.tradeType="{ item }">
          <span :style="{ color: item.tradeType === 'buy' ? 'green' : 'red', fontWeight: 'bold' }">
            {{ item.tradeType }}
          </span>
        </template>

      </v-data-table>
    </v-container>
  </v-app>
</template>

<script>
export default {
  data() {
    return {
      headers: [
        { text: 'Trade ID', value: 'tradeId', class: 'header-cell' },
        { text: 'Stock Name', value: 'stockName', class: 'header-cell' },
        { text: 'Quantity', value: 'quantity', class: 'header-cell' },
        { text: 'Trade Type', value: 'tradeType', class: 'header-cell' },
        { text: 'Price', value: 'price', class: 'header-cell' },
        { text: 'Trade Date', value: 'tradeDate', class: 'header-cell' },
      ],
      trades: [
        { tradeId: 1, stockName: 'AAPL', quantity: 10, tradeType: 'buy', price: 150, tradeDate: '2024-10-21' },
        { tradeId: 2, stockName: 'GOOGL', quantity: 5, tradeType: 'sell', price: 2800, tradeDate: '2024-10-20' },
        { tradeId: 3, stockName: 'TSLA', quantity: 2, tradeType: 'buy', price: 700, tradeDate: '2024-10-19' },
      ],
    };
  },
};
</script>

<style>
.v-data-table {
  max-width: 800px;
  margin: auto;
}

.header-cell {
  background-color: #BDBDBD;
  color: white;
}

.v-data-table .v-data-table__cell {
  transition: background-color 0.3s;
}

.v-data-table .v-data-table__cell:hover {
  background-color: rgba(0, 0, 0, 0.1);
}

.v-data-table .v-data-table__cell span {
  font-weight: normal;
}
</style>
