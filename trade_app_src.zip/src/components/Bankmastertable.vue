<template>
    <v-container>
      <v-data-table :headers="headers" :items="banks" class="elevation-1">
        <template v-slot:top>
          <v-toolbar flat>
            <v-toolbar-title>Bank List</v-toolbar-title>
          </v-toolbar>
        </template>
        <template v-slot:item.actions="{ item }">
          <v-icon small class="mr-2" @click="$emit('edit', item)">
            mdi-pencil
          </v-icon>
          <v-icon small @click="$emit('delete', item)">
            mdi-delete
          </v-icon>
        </template>
        <template v-slot:no-data>
          <v-btn color="primary" @click="$emit('initialize')">Reset</v-btn>
        </template>
      </v-data-table>
    </v-container>
  </template>
  
  <script>
  export default {
    props: {
      banks: {
        type: Array,
        default: () => [],
      },
    },
    data() {
      return {
        headers: [
          { text: 'Bank Name', value: 'bankName',class: 'header-cell' },
          { text: 'Branch Name', value: 'branchName' ,class: 'header-cell'},
          { text: 'IFSC Code', value: 'ifscCode',class: 'header-cell' },
          { text: 'Address', value: 'address' ,class: 'header-cell'},
          { text: 'Actions', value: 'actions', sortable: false ,class: 'header-cell'},
        ],
      };
    },
  };
  </script>
  
  <style scoped>

  </style>
  