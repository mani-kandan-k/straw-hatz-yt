<template>
    <div>
        <h1 class="text-center mb-4">Profile Overview</h1>
        <v-container fluid fill-height>
            <v-row align="center" justify="center">
                <v-col cols="12" sm="8" md="6">
                    <v-card>
                        <v-card-title class="text-center">Client Profile</v-card-title>
                        <v-card-text>
                            <v-form ref="form"  lazy-validation>
                                <v-row>
                                    <v-col cols="12" sm="6" md="6">
                                        <v-text-field :value="$store.state.user.firstName" label="Client Name" readonly
                                            prepend-icon="mdi-account" class="rounded"></v-text-field>
                                    </v-col>
                                    <v-col cols="12" sm="6" md="6">
                                        <v-text-field :value="$store.state.user.email" label="Email" readonly
                                            prepend-icon="mdi-email" class="rounded"></v-text-field>
                                    </v-col>
                                    <v-col cols="12" sm="6" md="6">
                                        <v-text-field :value="$store.state.user.phoneNumber" label="Phone Number"
                                            readonly prepend-icon="mdi-phone" class="rounded"></v-text-field>
                                    </v-col>
                                    <v-col cols="12" sm="6" md="6">
                                        <v-text-field :value="$store.state.user.panCardNumber" label="PAN Card Number"
                                            readonly prepend-icon="mdi-credit-card" class="rounded"></v-text-field>
                                    </v-col>
                                    <v-col cols="12" sm="6" md="6">
                                        <v-text-field :value="$store.state.user.kycStatus" label="KYC STATUS" readonly
                                            prepend-icon="mdi-check-circle" class="rounded"></v-text-field>
                                    </v-col>
                                    <v-col cols="12" sm="6" md="6">
                                        <v-text-field :value="$store.state.user.nomineeName" label="Nominee Name"
                                            readonly prepend-icon="mdi-account-heart" class="rounded"></v-text-field>
                                    </v-col>
                                </v-row>
                            </v-form>
                        </v-card-text>
                    </v-card>
                </v-col>
            </v-row>
        </v-container>
    </div>
</template>

<script>
export default {
    // data() {
    //     return {
    //         valid: false,
    //     };
    // },
    // methods: {
    //     submit() {
    //         if (this.$refs.form.validate()) {
    //             alert('Form submitted!');
    //         }
    //     },
    // },
}
</script>

<style>
.text-center {
    font-weight: bold;
}

.mb-4 {
    margin-bottom: 16px;
}

.rounded {
    border-radius: 8px;
}
</style>
