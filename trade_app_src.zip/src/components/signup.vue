<template>
    <div>
        <v-app>
            <v-container fluid class="fill-height"
                style="background-image: url('@/assets/background.jpg'); background-size: cover;">
                <v-row justify="center" align="center">
                    <v-card class="mx-4" style="max-width: 500px; background-color: rgba(255, 255, 255, 0.9);">
                        <v-toolbar color="#42A5F5" dark flat>
                            <v-card-title class="text-h6 font-weight-regular">
                                Login to your Account
                            </v-card-title>
                        </v-toolbar>
                        <v-form ref="form" v-model="form" class="pa-4 pt-6">
                            <v-text-field  :rules="phoneRules" label="Phone Number" clearable required></v-text-field>
                            <v-text-field v-model="email" :rules="[rules.email]" filled color="deep-purple"
                                label="Email address" type="email"></v-text-field>
                            <v-text-field v-model="password" :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'" filled
                                color="deep-purple" :rules="[rules.required, rules.length(8)]"
                                :type="show1 ? 'text' : 'password'" label="Password" hint="At least 8 characters"
                                counter @click:append="show1 = !show1"></v-text-field>
                            <v-checkbox v-model="agreement" :rules="[rules.required]" color="#42A5F5">
                                <template v-slot:label>
                                    I agree to the&nbsp;
                                    <a href="#" @click.stop.prevent="dialog = true">Terms of Service</a>
                                    &nbsp;and&nbsp;
                                    <a href="#" @click.stop.prevent="dialog = true">Privacy Policy</a>*
                                </template>
                            </v-checkbox>
                        </v-form>
                        <v-divider></v-divider>
                        <v-card-actions>
                            <v-btn text @click="$refs.form.reset()">Clear</v-btn>
                            <v-spacer></v-spacer>
                            <v-btn :disabled="!form" @click="submit" :loading="isLoading" class="white--text"
                                color="#42A5F5">
                                LOGIN
                            </v-btn>
                        </v-card-actions>
                        <v-dialog v-model="dialog" absolute max-width="400" persistent>
                            <v-card>
                                <v-card-title class="text-h5 grey lighten-3">Legal</v-card-title>
                                <v-divider></v-divider>
                                <v-card-actions>
                                    <v-btn text @click="agreement = false; dialog = false">No</v-btn>
                                    <v-spacer></v-spacer>
                                    <v-btn class="white--text" color="deep-purple accent-4"
                                        @click="agreement = true; dialog = false">
                                        Yes
                                    </v-btn>
                                </v-card-actions>
                            </v-card>
                        </v-dialog>
                    </v-card>
                </v-row>
            </v-container>
        </v-app>
    </div>
</template>
<script>
export default {
    data() {
        return {
            show1: false,
            agreement: false,
            dialog: false,
            email: '',
            form: false,
            isLoading: false,
            password: '',
            phone: '',
            phoneRules: [
                    (v) => !!v || 'Phone number is required',
                    (v) => /^\d{10}$/.test(v) || 'Must be a valid 10-digit phone number',
                ],
            rules: {
                
                email: v => /.+@.+\..+/.test(v) || 'Please enter a valid email',
                length: len => v => (v || '').length >= len || `Invalid character length, required ${len}`,
                required: v => !!v || 'This field is required',
            },
        };
    },
    methods: {
        submit() {
            if (this.$refs.form.validate()) {
                this.isLoading = true;

                setTimeout(() => {
                    this.isLoading = false;
                    alert('Login Successfully!');
                    this.$router.push('/clientreg');
                }, 1000);
            }
        },
    },
};
</script>
<style scoped>
/* .fill-height {
    min-height: 100vh;
} */
</style>