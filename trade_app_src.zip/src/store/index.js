import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    user: {},
    trans: {},
    usermanagement: {}
  },
  mutations: {
    setuser(state, userdata) {
      state.user = userdata;
    },
    settrans(state, trans1) {
      state.trans = trans1; 
    },
    setusermanagement(state,usermanagement1) {
      state.usermanagement=usermanagement1;
    }
  },
  actions: {},
  modules: {},
});
