<template>
    <div>
        <Logopage></Logopage>
    </div>
</template>
<script>
 import Logopage from '../components/Logopage';
export default {
   
    components: {
        Logopage
    }
}
</script>