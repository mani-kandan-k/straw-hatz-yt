<template>
    <div>
        <AdminDashboard></AdminDashboard>
    </div>
</template>
<script>
import AdminDashboard from "../components/AdminDashboard.vue"
export default{
   name :"Admindashboard",
   components:{
    AdminDashboard
   }

}
</script>