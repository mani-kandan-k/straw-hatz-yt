<template>
    <div>
        <Clientdashboard></Clientdashboard>
    </div>
</template>
<script>
import Clientdashboard from "../components/Clientdashboard.vue"
export default{
    name:"client",
    components:{
        Clientdashboard
    }
}
</script>