<template>
    <div>
        <signup></signup>
    </div>
</template>
<script>
import signup from '../components/signup.vue';

export default {
    components: {
        signup
    },
};
</script>