<template>
  <div>
    <Clientregistrationc></Clientregistrationc>
   
  </div>
</template>

<script>
// @ is an alias to /src

import Clientregistrationc from "../components/Clientregistrationc.vue";

export default {
  name:"Home",
  components:{
    Clientregistrationc,
   
  }
};
</script>
