<template>
  <v-app>
    <v-app-bar app color="#4DD0E1" dark>
      <v-img src="../src/assets/logo.png" max-height="80" max-width="180"></v-img>
      <v-tab @click="goToClient">Client</v-tab>
      <v-tab @click="goToAdmin">Admin</v-tab>
    </v-app-bar>

    <v-main>
      <router-view />
    </v-main>
  </v-app>
</template>

<script>
export default {
  name: "App",

  methods: {
    goToClient() {
      this.$router.push('/'); 
    },
    goToAdmin() {
      this.$router.push('/admin');
    }
  }
};
</script>
