import Vue from "vue";
import VueRouter from "vue-router";
import Client from "../views/Client.vue";
import clientdashboardview from "../views/clientdashboardview";
import Admindashboardview from "../views/Admindashboardview";
import logo from "../views/logo.vue";
import signuppage from "../views/signuppage.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "logo",
    component: logo,
  },
   {
    path: "/clientreg",
    name: "Home",
    component: Client,
  },
  {
    path: "/client",
    name: "client",
    component: clientdashboardview,
  },
  {
    path: "/admin",
    name: "Admindashboard",
    component: Admindashboardview,
  },
  {
    path: "/logo",
    name: "logo",
    component: logo,
  },
  {
    path: "/signup",
    name: "signuppage",
    component: signuppage,
  },
  // {
  //   path: "/profile",
  //   name: "profile",
  //   component: profileview,
  // },
  // {
  //   path: "/bank",
  //   name: "bank",
  //   component: Bankdetailsview,
  // },
 
 
  
  {
    path: "/about",
    name: "About",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/About.vue"),
  },
];

const router = new VueRouter({
  routes,
});

export default router;
